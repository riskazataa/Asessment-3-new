package org.d3if4062.assessment3.model

data class ObjekNonPpn(
    val nama: String,
    val gambar: String
)