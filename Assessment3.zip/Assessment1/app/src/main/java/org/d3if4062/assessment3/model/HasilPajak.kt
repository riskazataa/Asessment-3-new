package org.d3if4062.assessment3.model

data class HasilPajak(
    val ppn: Double,
    val total: Double,
)
